
$(document).ready(function(){
	$('.header').height($(window).height());
})


function tellMeMore(){
    document.getElementById("tmm").innerHTML="hi";
}